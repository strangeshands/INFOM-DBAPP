CREATE DATABASE  IF NOT EXISTS `dbelectric` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `dbelectric`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbelectric
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `address_id` varchar(5) NOT NULL,
  `address_details` varchar(100) NOT NULL,
  `barangay` varchar(70) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postal_code` varchar(4) NOT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES ('00001','123 Sampaguita St., Greenfield Subdivision','Barangay Santo Niño','Quezon City','1103'),('00002','456 Dama de Noche St., Eastwood City','Barangay Bagumbayan','Quezon City','1110'),('00003','789 Aster St., Valle Verde 1','Barangay Addition Hills','Mandaluyong City','1550'),('00004','101 Rizal St., Santolan Town Plaza','Barangay San Antonio','Pasig City','1600'),('00005','202 Malvar St., Villa Solana','Barangay 177','Caloocan City','1400'),('00006','345 Acacia St., Westgrove Heights','Barangay San Jose','Taguig City','1630'),('00007','678 Magnolia Ave., Tandang Sora','Barangay Culiat','Quezon City','1116'),('00008','912 Camia St., Villa Verde','Barangay Plainview','Mandaluyong City','1552'),('00009','1017 Mango Rd., Camella Homes','Barangay Cupang','Muntinlupa City','1771'),('00010','58 Guava St., Windsor Place Subdivision','Barangay Tinajeros','Malabon City','1470');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billings`
--

DROP TABLE IF EXISTS `billings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billings` (
  `billing_id` varchar(8) NOT NULL,
  `meter_id` varchar(5) NOT NULL,
  `consumption_fee` decimal(10,2) DEFAULT NULL,
  `service_fee` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `consumption` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_status` enum('paid','unpaid') NOT NULL,
  PRIMARY KEY (`billing_id`),
  KEY `meter_bill` (`meter_id`),
  CONSTRAINT `meter_bill` FOREIGN KEY (`meter_id`) REFERENCES `meters` (`meter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billings`
--

LOCK TABLES `billings` WRITE;
/*!40000 ALTER TABLE `billings` DISABLE KEYS */;
INSERT INTO `billings` VALUES ('BIL00001','00001',2467.20,300.00,2767.20,'2022-02-13','2022-02-28',205.60,'2022-03-15','paid'),('BIL00002','00001',2500.80,0.00,2500.80,'2022-03-01','2022-03-31',208.40,'2022-04-15','paid'),('BIL00003','00001',2515.20,0.00,2515.20,'2022-04-01','2022-04-30',209.60,'2022-05-15','paid'),('BIL00004','00001',2496.00,0.00,2496.00,'2022-05-01','2022-05-31',207.50,'2022-06-15','paid'),('BIL00005','00001',2466.00,0.00,2466.00,'2022-06-01','2022-06-30',205.50,'2022-07-15','paid'),('BIL00006','00001',2281.20,0.00,2281.20,'2022-07-01','2022-07-31',190.10,'2022-08-15','paid'),('BIL00007','00001',2466.00,0.00,2466.00,'2022-08-01','2022-08-31',205.50,'2022-09-15','unpaid'),('BIL00008','00001',2306.40,0.00,2306.40,'2022-09-01','2022-09-30',192.20,'2022-10-15','paid'),('BIL00009','00001',2302.80,0.00,2302.80,'2022-10-01','2022-10-31',191.90,'2022-11-15','paid'),('BIL00010','00001',2502.00,0.00,2502.00,'2022-11-01','2022-11-30',208.50,'2022-12-15','paid'),('BIL00011','00001',2443.20,0.00,2443.20,'2022-12-01','2022-12-31',203.60,'2023-01-15','paid'),('BIL00012','00001',2462.40,150.00,2612.40,'2023-01-01','2023-01-31',205.20,'2023-02-15','unpaid'),('BIL00013','00001',2455.20,0.00,2455.20,'2023-02-01','2023-02-28',204.60,'2023-03-15','paid'),('BIL00014','00001',2485.20,0.00,2485.20,'2023-03-01','2023-03-31',207.10,'2023-04-15','unpaid'),('BIL00015','00001',2320.80,0.00,2320.80,'2023-04-01','2023-04-30',193.40,'2023-05-15','paid'),('BIL00016','00001',2394.00,0.00,2394.00,'2023-05-01','2023-05-31',199.50,'2023-06-15','paid'),('BIL00017','00001',2474.40,0.00,2474.40,'2023-06-01','2023-06-30',206.20,'2023-07-15','paid'),('BIL00018','00001',2336.40,0.00,2336.40,'2023-07-01','2023-07-31',194.70,'2023-08-15','unpaid'),('BIL00019','00001',2355.60,150.00,2505.60,'2024-02-06','2024-02-29',196.30,'2024-03-15','paid'),('BIL00020','00001',2318.40,0.00,2318.40,'2024-03-01','2024-03-31',193.20,'2024-04-15','unpaid'),('BIL00021','00002',2416.80,300.00,2716.80,'2022-02-14','2022-02-28',201.40,'2022-03-15','paid'),('BIL00022','00002',2382.00,0.00,2382.00,'2022-03-01','2022-03-31',198.50,'2022-04-15','paid'),('BIL00023','00002',2397.60,0.00,2397.60,'2022-04-01','2022-04-30',199.80,'2022-05-15','paid'),('BIL00024','00002',2415.60,0.00,2415.60,'2022-05-01','2022-05-31',200.50,'2022-06-15','unpaid'),('BIL00025','00002',2421.60,0.00,2421.60,'2022-06-01','2022-06-30',201.80,'2022-07-15','paid'),('BIL00026','00002',2481.60,0.00,2481.60,'2022-07-01','2022-07-31',206.80,'2022-08-15','paid'),('BIL00027','00002',2487.60,0.00,2487.60,'2022-08-01','2022-08-31',207.30,'2022-09-15','paid'),('BIL00028','00002',2350.80,0.00,2350.80,'2022-09-01','2022-09-30',195.90,'2022-10-15','unpaid'),('BIL00029','00002',2520.00,0.00,2520.00,'2022-10-01','2022-10-31',210.00,'2022-11-15','paid'),('BIL00030','00002',2420.40,0.00,2420.40,'2022-11-01','2022-11-30',201.70,'2022-12-15','paid'),('BIL00031','00002',2280.00,0.00,2280.00,'2022-12-01','2022-12-31',190.00,'2023-01-15','paid'),('BIL00032','00002',2374.80,0.00,2374.80,'2023-01-01','2023-01-31',197.90,'2023-02-15','paid'),('BIL00033','00002',2386.80,0.00,2386.80,'2023-02-01','2023-02-28',198.90,'2023-03-15','paid'),('BIL00034','00002',2304.00,0.00,2304.00,'2023-03-01','2023-03-31',192.00,'2023-04-15','unpaid'),('BIL00035','00002',2372.40,0.00,2372.40,'2023-04-01','2023-04-30',197.70,'2023-05-15','paid'),('BIL00036','00002',2316.00,0.00,2316.00,'2023-05-01','2023-05-31',193.00,'2023-06-15','paid'),('BIL00037','00002',2456.40,0.00,2456.40,'2023-06-01','2023-06-30',204.70,'2023-07-15','paid'),('BIL00038','00002',2355.60,0.00,2355.60,'2023-07-01','2023-07-31',196.30,'2023-08-15','paid'),('BIL00039','00002',2480.40,0.00,2480.40,'2023-08-01','2023-08-31',206.70,'2023-09-15','paid'),('BIL00040','00002',2505.60,0.00,2505.60,'2023-09-01','2023-09-30',208.80,'2023-10-15','paid'),('BIL00041','00002',2500.80,0.00,2500.80,'2023-10-01','2023-10-31',208.40,'2023-11-15','unpaid'),('BIL00042','00002',2388.00,0.00,2388.00,'2023-11-01','2023-11-30',199.00,'2023-12-15','paid'),('BIL00043','00002',2421.60,0.00,2421.60,'2023-12-01','2023-12-31',201.80,'2024-01-15','paid'),('BIL00044','00002',2325.60,0.00,2325.60,'2024-01-01','2024-01-31',193.80,'2024-02-15','paid'),('BIL00045','00002',2475.60,0.00,2475.60,'2024-02-01','2024-02-29',206.30,'2024-03-15','paid'),('BIL00046','00002',2406.00,0.00,2406.00,'2024-03-01','2024-03-31',200.50,'2024-04-15','unpaid'),('BIL00047','00003',2368.80,300.00,2668.80,'2023-01-16','2023-01-31',197.40,'2023-02-15','paid'),('BIL00048','00003',2491.20,0.00,2491.20,'2023-02-01','2023-02-28',207.60,'2023-03-15','paid'),('BIL00049','00003',2388.00,0.00,2388.00,'2023-03-01','2023-03-31',199.00,'2023-04-15','paid'),('BIL00050','00003',2450.40,0.00,2450.40,'2023-04-01','2023-04-30',204.20,'2023-05-15','unpaid'),('BIL00051','00003',2449.20,0.00,2449.20,'2023-05-01','2023-05-31',204.10,'2023-06-15','paid'),('BIL00052','00003',2358.00,0.00,2358.00,'2023-06-01','2023-06-30',196.50,'2023-07-15','paid'),('BIL00053','00003',2389.20,0.00,2389.20,'2023-07-01','2023-07-31',199.10,'2023-08-15','paid'),('BIL00054','00003',2323.20,0.00,2323.20,'2023-08-01','2023-08-31',193.60,'2023-09-15','paid'),('BIL00055','00003',2457.60,0.00,2457.60,'2023-09-01','2023-09-30',190.30,'2023-10-15','paid'),('BIL00056','00003',2457.60,0.00,2457.60,'2023-10-01','2023-10-31',204.80,'2023-11-15','paid'),('BIL00057','00003',2314.80,0.00,2314.80,'2023-11-01','2023-11-30',192.90,'2023-12-15','paid'),('BIL00058','00003',2360.40,0.00,2360.40,'2023-12-01','2023-12-31',196.70,'2024-01-15','paid'),('BIL00059','00003',2425.20,0.00,2425.20,'2024-01-01','2024-01-31',202.10,'2024-02-15','unpaid'),('BIL00060','00003',2310.00,150.00,2460.00,'2024-02-01','2024-02-29',192.50,'2024-03-15','paid'),('BIL00061','00003',2359.20,0.00,2359.20,'2024-03-01','2024-03-31',196.60,'2024-04-15','paid'),('BIL00062','00004',3036.00,300.00,3336.00,'2023-04-28','2023-04-30',253.00,'2023-05-15','paid'),('BIL00063','00004',2990.40,0.00,2990.40,'2023-05-01','2023-05-31',249.20,'2023-06-15','paid'),('BIL00064','00004',3112.80,0.00,3112.80,'2023-06-01','2023-06-30',259.40,'2023-07-15','paid'),('BIL00065','00004',2874.00,0.00,2874.00,'2023-07-01','2023-07-31',239.50,'2023-08-15','paid'),('BIL00066','00004',2913.60,0.00,2913.60,'2023-08-01','2023-08-31',242.80,'2023-09-15','paid'),('BIL00067','00004',2881.20,0.00,2881.20,'2023-09-01','2023-09-30',240.10,'2023-10-15','paid'),('BIL00068','00004',2938.80,150.00,3088.80,'2023-10-01','2023-10-31',244.90,'2023-11-15','paid'),('BIL00069','00004',3069.60,0.00,3069.60,'2023-11-01','2023-11-30',255.80,'2023-12-15','paid'),('BIL00070','00004',2928.00,0.00,2928.00,'2023-12-01','2023-12-31',244.00,'2024-01-15','paid'),('BIL00071','00004',2967.60,0.00,2967.60,'2024-01-01','2024-01-31',247.30,'2024-02-15','paid'),('BIL00072','00004',3151.20,0.00,3151.20,'2024-02-01','2024-02-29',262.60,'2024-03-15','paid'),('BIL00073','00004',2985.60,0.00,2985.60,'2024-03-01','2024-03-31',248.80,'2024-04-15','paid'),('BIL00074','00005',1731.60,300.00,2031.60,'2023-06-13','2023-06-30',144.30,'2023-07-15','paid'),('BIL00075','00005',1915.20,0.00,1915.20,'2023-07-01','2023-07-31',159.60,'2023-08-15','paid'),('BIL00076','00005',1708.80,0.00,1708.80,'2023-08-01','2023-08-31',142.40,'2023-09-15','paid'),('BIL00077','00005',1786.80,0.00,1786.80,'2023-09-01','2023-09-30',148.90,'2023-10-15','paid'),('BIL00078','00005',1761.60,0.00,1761.60,'2023-10-01','2023-10-31',146.80,'2023-11-15','unpaid'),('BIL00079','00005',1812.00,0.00,1812.00,'2023-11-01','2023-11-30',151.00,'2023-12-15','paid'),('BIL00080','00005',1746.00,0.00,1746.00,'2023-12-01','2023-12-31',145.50,'2024-01-15','paid'),('BIL00081','00005',1683.60,0.00,1683.60,'2024-01-01','2024-01-31',140.30,'2024-02-15','paid'),('BIL00082','00005',1735.20,0.00,1735.20,'2024-02-01','2024-02-29',144.60,'2024-03-15','paid'),('BIL00083','00005',1911.60,300.00,2211.60,'2024-03-01','2024-03-31',159.30,'2024-04-15','paid'),('BIL00084','00006',2673.60,300.00,2973.60,'2023-07-11','2023-07-31',222.80,'2023-08-15','unpaid'),('BIL00085','00006',2766.00,0.00,2766.00,'2023-08-01','2023-08-31',230.50,'2023-09-15','paid'),('BIL00086','00006',2756.40,150.00,2756.40,'2023-09-01','2023-09-30',229.70,'2023-10-15','paid'),('BIL00087','00006',2841.60,0.00,2841.60,'2023-10-01','2023-10-31',236.80,'2023-11-15','paid'),('BIL00088','00006',2670.00,0.00,2670.00,'2023-11-01','2023-11-30',222.50,'2023-12-15','paid'),('BIL00089','00006',2829.60,0.00,2829.60,'2023-12-01','2023-12-31',235.80,'2024-01-15','paid'),('BIL00090','00006',2874.00,0.00,2874.00,'2024-01-01','2024-01-31',239.50,'2024-02-15','paid'),('BIL00091','00006',2642.40,0.00,2642.40,'2024-02-01','2024-02-29',220.20,'2024-03-15','paid'),('BIL00092','00006',2727.60,0.00,2727.60,'2024-03-01','2024-03-31',227.30,'2024-04-15','paid'),('BIL00093','00007',3075.60,300.00,3375.60,'2023-09-28','2023-09-30',256.30,'2023-10-15','paid'),('BIL00094','00007',3303.60,0.00,3303.60,'2023-10-01','2023-10-31',275.30,'2023-11-15','paid'),('BIL00095','00007',3331.20,0.00,3331.20,'2023-11-01','2023-11-30',277.60,'2023-12-15','paid'),('BIL00096','00007',3339.60,0.00,3339.60,'2023-12-01','2023-12-31',278.30,'2024-01-15','unpaid'),('BIL00097','00007',3129.60,450.00,3279.60,'2024-01-01','2024-01-31',260.80,'2024-02-15','paid'),('BIL00098','00008',1993.20,300.00,2293.20,'2023-12-25','2023-12-31',166.10,'2024-01-15','paid'),('BIL00099','00008',1993.20,0.00,1993.20,'2024-01-01','2024-01-31',166.10,'2024-02-15','paid'),('BIL00100','00008',1938.00,0.00,1938.00,'2024-02-01','2024-02-29',161.50,'2024-03-15','paid'),('BIL00101','00008',1820.40,0.00,1820.40,'2024-03-01','2024-03-31',151.70,'2024-04-15','paid'),('BIL00102','00009',1554.00,300.00,1854.00,'2024-01-25','2024-01-31',129.50,'2024-02-15','paid'),('BIL00103','00009',1593.60,0.00,1593.60,'2024-02-01','2024-02-29',132.80,'2024-03-15','paid'),('BIL00104','00009',1486.80,0.00,1486.80,'2024-03-01','2024-03-31',123.90,'2024-04-15','paid'),('BIL00105','00010',2400.00,300.00,2700.00,'2024-03-18','2024-03-31',200.00,'2024-04-15','paid');
/*!40000 ALTER TABLE `billings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractor_registration`
--

DROP TABLE IF EXISTS `contractor_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractor_registration` (
  `registration_id` varchar(8) NOT NULL,
  `contractor_id` varchar(5) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`registration_id`),
  UNIQUE KEY `contractor_id` (`contractor_id`),
  CONSTRAINT `contractor_registered` FOREIGN KEY (`contractor_id`) REFERENCES `contractors` (`contractor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractor_registration`
--

LOCK TABLES `contractor_registration` WRITE;
/*!40000 ALTER TABLE `contractor_registration` DISABLE KEYS */;
INSERT INTO `contractor_registration` VALUES ('REG00001','00001','2022-02-01'),('REG00002','00002','2022-02-01'),('REG00003','00003','2022-02-01'),('REG00004','00004','2022-02-01'),('REG00005','00005','2022-02-01'),('REG00006','00006','2022-02-01');
/*!40000 ALTER TABLE `contractor_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contractors`
--

DROP TABLE IF EXISTS `contractors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contractors` (
  `contractor_id` varchar(5) NOT NULL,
  `service_id` varchar(5) NOT NULL,
  `job_title` varchar(45) NOT NULL,
  `last_name` varchar(70) NOT NULL,
  `first_name` varchar(70) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`contractor_id`),
  UNIQUE KEY `contact_number` (`contact_number`),
  KEY `contractor_specialty` (`service_id`),
  CONSTRAINT `contractor_specialty` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contractors`
--

LOCK TABLES `contractors` WRITE;
/*!40000 ALTER TABLE `contractors` DISABLE KEYS */;
INSERT INTO `contractors` VALUES ('00001','00006','Maintenance Technician','Santos','Oliver','0916 284 5028','active'),('00002','00005','Repair Technician','Lansangan','Maricela','0902 723 8313 ','active'),('00003','00004','Utility Technician','Roxas','Christian','0936 815 9465','active'),('00004','00003','Utility Technician','Bernardino','Loren','0963 641 7260','active'),('00005','00002','Setup Specialist','Malano','Monte','0992 890 7492','active'),('00006','00001','Setup Specialist','Magallanes','Oscar','0990 521 6300','active');
/*!40000 ALTER TABLE `contractors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_registration`
--

DROP TABLE IF EXISTS `customer_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_registration` (
  `registration_id` varchar(8) NOT NULL,
  `customer_id` varchar(5) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`registration_id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  CONSTRAINT `customer_registered` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_registration`
--

LOCK TABLES `customer_registration` WRITE;
/*!40000 ALTER TABLE `customer_registration` DISABLE KEYS */;
INSERT INTO `customer_registration` VALUES ('REG00001','00001','2022-02-13'),('REG00002','00002','2022-02-14'),('REG00003','00003','2023-01-16'),('REG00004','00004','2023-04-28'),('REG00005','00005','2023-06-13'),('REG00006','00006','2023-07-11'),('REG00007','00007','2023-09-28'),('REG00008','00008','2023-12-25'),('REG00009','00009','2024-01-25'),('REG00010','00010','2024-03-18');
/*!40000 ALTER TABLE `customer_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `customer_id` varchar(5) NOT NULL,
  `permanent_address` varchar(5) NOT NULL,
  `last_name` varchar(70) NOT NULL,
  `first_name` varchar(70) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `contact_number` (`contact_number`),
  KEY `customer_address` (`permanent_address`),
  CONSTRAINT `customer_address` FOREIGN KEY (`permanent_address`) REFERENCES `addresses` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES ('00001','00001','Evangelista','Yvette','0928 492 3470','active'),('00002','00002','Lorenzo','Jaiden','0929 386 1080','inactive'),('00003','00003','Cruz','Joel','0919 429 4269','active'),('00004','00004','Sardido','Joselyn','0934 813 5743','active'),('00005','00005','Villaruz','Aron','0975 132 7962','inactive'),('00006','00006','Ramirez','Mateo','0917 345 6789','active'),('00007','00007','Fernandez','Althea','0932 890 1122','inactive'),('00008','00008','Reyes','Miguel','0998 123 4567','active'),('00009','00009','Bautista','Sofia','0945 678 9101','active'),('00010','00010','Delgado','Juan','0920 556 7890','active');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meters`
--

DROP TABLE IF EXISTS `meters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meters` (
  `meter_id` varchar(5) NOT NULL,
  `customer_id` varchar(5) NOT NULL,
  `install_address` varchar(5) NOT NULL,
  `account_number` varchar(20) NOT NULL,
  `installation_date` date NOT NULL,
  `status` enum('disconnected','removed','connected') NOT NULL,
  PRIMARY KEY (`meter_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `meter_address` (`install_address`),
  KEY `meter_owner` (`customer_id`),
  CONSTRAINT `meter_address` FOREIGN KEY (`install_address`) REFERENCES `addresses` (`address_id`),
  CONSTRAINT `meter_owner` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meters`
--

LOCK TABLES `meters` WRITE;
/*!40000 ALTER TABLE `meters` DISABLE KEYS */;
INSERT INTO `meters` VALUES ('00001','00001','00001','5892 4802 4328 9276','2022-02-13','connected'),('00002','00002','00002','2569 3347 8834 4920','2022-02-14','disconnected'),('00003','00003','00003','9039 2409 2313 6721','2023-01-16','connected'),('00004','00004','00004','4138 7314 9871 3790','2023-04-28','connected'),('00005','00005','00005','0946 7137 7219 1804','2023-06-13','removed'),('00006','00006','00006','4328 0148 4309 1238','2023-07-11','connected'),('00007','00007','00007','432 9083 9483 4322','2023-09-28','removed'),('00008','00008','00008','5345 0301 9321 7743','2023-12-25','connected'),('00009','00009','00009','3247 9332 3819 9932','2024-01-25','connected'),('00010','00010','00010','3217 3291 9321 1231','2024-03-18','connected');
/*!40000 ALTER TABLE `meters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `payment_id` varchar(8) NOT NULL,
  `billing_id` varchar(8) NOT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `payment_type` enum('cash','credit','debit','e-wallet') NOT NULL,
  `payment_date` date NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `payment_bill` (`billing_id`),
  CONSTRAINT `payment_bill` FOREIGN KEY (`billing_id`) REFERENCES `billings` (`billing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `service_id` varchar(5) NOT NULL,
  `service_type` varchar(45) NOT NULL,
  `service_fee` decimal(10,2) NOT NULL,
  `description` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`service_id`),
  UNIQUE KEY `service_type` (`service_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES ('00001','Installation',300.00,'Installation of new meter as per customer request'),('00002','Uninstallation',300.00,'Uninstall existing meter as per customer or admin request'),('00003','Disconnection',0.00,'Disconnection of electricity due to noncompliance to the rules'),('00004','Reconnection',100.00,'Reconnection of electricity from disconnection'),('00005','Repair',150.00,'Repair as per customer request'),('00006','Maintenance',0.00,'Check up of meter as per request of customer or admin');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services_availed`
--

DROP TABLE IF EXISTS `services_availed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services_availed` (
  `transaction_id` varchar(8) NOT NULL,
  `customer_id` varchar(5) NOT NULL,
  `meter_id` varchar(5) NOT NULL,
  `service_id` varchar(5) NOT NULL,
  `contractor_id` varchar(5) NOT NULL,
  `billing_id` varchar(8) DEFAULT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `customer_availed` (`customer_id`),
  KEY `meter_worked` (`meter_id`),
  KEY `service_worked` (`service_id`),
  KEY `contractor_worked` (`contractor_id`),
  KEY `billing_assigned` (`billing_id`),
  CONSTRAINT `billing_assigned` FOREIGN KEY (`billing_id`) REFERENCES `billings` (`billing_id`),
  CONSTRAINT `contractor_worked` FOREIGN KEY (`contractor_id`) REFERENCES `contractors` (`contractor_id`),
  CONSTRAINT `customer_availed` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  CONSTRAINT `meter_worked` FOREIGN KEY (`meter_id`) REFERENCES `meters` (`meter_id`),
  CONSTRAINT `service_worked` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services_availed`
--

LOCK TABLES `services_availed` WRITE;
/*!40000 ALTER TABLE `services_availed` DISABLE KEYS */;
INSERT INTO `services_availed` VALUES ('SER00001','00001','00001','00001','00006','BIL00001','2022-02-13'),('SER00002','00001','00001','00005','00006','BIL00005','2022-06-27'),('SER00003','00001','00001','00005','00006','BIL00012','2023-01-02'),('SER00004','00001','00001','00004','00003','BIL00018','2023-07-18'),('SER00005','00001','00001','00004','00003','BIL00019','2024-02-06'),('SER00006','00002','00002','00001','00006','BIL00021','2022-02-14'),('SER00007','00002','00002','00001','00006','BIL00029','2022-10-15'),('SER00008','00002','00002','00006','00006','BIL00035','2023-04-01'),('SER00009','00003','00003','00001','00006','BIL00047','2023-01-16'),('SER00010','00003','00003','00006','00006','BIL00057','2023-11-06'),('SER00011','00003','00003','00005','00006','BIL00060','2024-02-13'),('SER00012','00004','00004','00001','00006','BIL00062','2023-04-28'),('SER00013','00004','00004','00005','00006','BIL00068','2023-10-10'),('SER00014','00005','00005','00001','00006','BIL00074','2023-06-13'),('SER00015','00005','00005','00006','00006','BIL00078','2023-10-09'),('SER00016','00005','00005','00001','00006','BIL00081','2024-01-25'),('SER00017','00005','00005','00002','00006','BIL00083','2024-03-17'),('SER00018','00006','00006','00001','00005','BIL00084','2023-07-11'),('SER00019','00006','00006','00006','00006','BIL00086','2023-09-20'),('SER00020','00006','00006','00006','00006','BIL00086','2023-09-22'),('SER00021','00006','00006','00006','00006','BIL00091','2024-02-04'),('SER00022','00007','00007','00001','00005','BIL00093','2023-09-28'),('SER00023','00007','00007','00006','00006','BIL00095','2023-11-12'),('SER00024','00007','00007','00005','00006','BIL00097','2024-01-07'),('SER00025','00007','00007','00002','00002','BIL00097','2024-01-20'),('SER00026','00008','00008','00001','00005','BIL00098','2023-12-25'),('SER00027','00008','00008','00006','00001','BIL00100','2024-02-23'),('SER00028','00009','00009','00001','00005','BIL00102','2024-01-25'),('SER00029','00010','00010','00001','00006','BIL00105','2024-03-18');
/*!40000 ALTER TABLE `services_availed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-23 19:47:26
