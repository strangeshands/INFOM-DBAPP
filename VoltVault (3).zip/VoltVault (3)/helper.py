# ===== VALIDATORS ===== #

# ===== GENARATORS ===== #
def generateID(cursor, table, idField, prefix=""):
    cursor.execute(f"SELECT MAX({idField}) AS max_id FROM {table}")
    result = cursor.fetchone()

    if result:
        try:
            last_id = result[0]
        except Exception as e:
            last_id = result['max_id']
        
        number = last_id
        if len(last_id) > 3 and last_id[:3].isalpha():
            number = last_id[3:]
        elif len(last_id) > 3 and last_id[:3].isdigit():
            number = last_id

        new_number = str(int(number) + 1).zfill(5)
    else:
        new_number = '00001'

    if prefix != "":
        new_id = prefix + new_number
    else:
        new_id = new_number

    return new_id

import random
def generate_account_number(cursor):
    while True:
        # Generate a random account number in the format XXXX XXXX XXXX XXXX
        new_can = " ".join(["".join([str(random.randint(0, 9)) for _ in range(4)]) for _ in range(4)])
        
        # Check if this CAN already exists in the meters table
        cursor.execute("SELECT COUNT(*) FROM meters WHERE account_number = %s", (new_can,))
        result = cursor.fetchone()

        if result and result[0] == 0:
            return new_can

