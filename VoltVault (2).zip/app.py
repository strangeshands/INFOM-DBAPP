from flask import Flask, render_template, request, redirect
from datetime import date
import mysql.connector
import calendar

# contains helper functions (validators and checkers)
import helper

app = Flask(__name__)

# establish connection to DB
def connect_to_db():
    connection = mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="EastWind_131965", # edit password
        database="dbelectric"
    )
    return connection

# route to home
@app.route('/')
def index():
    return render_template('HomePage.html')

# route to services
@app.route('/services')
def services():
    try:
        connection = connect_to_db()
        cursor = connection.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT service_id, service_type, service_fee, description 
            FROM services 
        """)
        services = cursor.fetchall()
        
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        services = []
    
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
    
    return render_template('ServicesPage.html', services=services)

# managing services
@app.route('/services/manage', methods=['GET', 'POST'])
def manage_service(service_id=None):
    connection = connect_to_db()
    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        service_type = request.form['serviceType']
        service_fee = request.form['serviceFee']
        description = request.form['description']
        selected_service = request.form.get('existingServices')

        if selected_service:
            cursor.execute("""
                UPDATE services
                SET service_type = %s, service_fee = %s, description = %s
                WHERE service_id = %s
            """, (service_type, service_fee, description, selected_service))

        connection.commit()
        connection.close()
        return redirect('/services')

    if service_id: 
        cursor.execute("""
            SELECT service_id, service_type, service_fee, description
            FROM services
            WHERE service_id = %s
        """, (service_id,))
        service = cursor.fetchone()
    else: 
        service = None

    cursor.execute("SELECT service_id, service_type, service_fee, description FROM services")
    all_services = cursor.fetchall()
    connection.close()
    return render_template('InputService.html', service=service, all_services=all_services)

# contractors page
@app.route('/contractors', methods=['GET', 'POST'])
def contractors():
    try:
        connection = connect_to_db()
        cursor = connection.cursor(dictionary=True)

        # Get all available services for the filter dropdown
        cursor.execute("SELECT service_type FROM services")
        services = cursor.fetchall()

        # Get the filter values from the request
        status_filter = request.args.get('statusFilter')
        last_name_filter = request.args.get('lastNameFilter')
        first_name_filter = request.args.get('firstNameFilter')

        # Base query to retrieve contractors
        query = """
            SELECT c.contractor_id, c.job_title, c.last_name, c.first_name, c.contact_number, c.status, s.service_type AS specialization
            FROM contractors c
            JOIN services s ON c.service_id = s.service_id
        """
        
        conditions = []
        params = []

        # Filter contractors based on user input
        if status_filter:
            conditions.append("c.status = %s")
            params.append(status_filter)

        if last_name_filter:
            conditions.append("c.last_name LIKE %s")
            params.append(f"%{last_name_filter}%")

        if first_name_filter:
            conditions.append("c.first_name LIKE %s")
            params.append(f"%{first_name_filter}%")

        # If filters exist, add them to the query
        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        # Execute the query with any filters applied
        cursor.execute(query, params)
        contractors = cursor.fetchall()

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        contractors = []

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    return render_template('ContractorsPage.html', contractors=contractors, services=services)

# route to contractors by service
@app.route('/contractorsByService/<service_id>')
def contractorsByService(service_id):
    try:
        connection = connect_to_db()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("SELECT service_type FROM services WHERE service_id = %s", (service_id,))
        service = cursor.fetchone()

        cursor.execute("""
            SELECT c.contractor_id, c.job_title, c.last_name, c.first_name, c.contact_number, c.status, s.service_type AS specialization
            FROM contractors c
            JOIN services s ON c.service_id = s.service_id
            WHERE c.service_id = %s
        """, (service_id,))
        contractors = cursor.fetchall()

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        service = None
        contractors = []

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
        
    return render_template('ContractorsPage.html', contractors=contractors, service_type=service['service_type'] if service else 'Unknown')

# route to customers
@app.route('/customers', methods=['GET'])
def customers():
    try:
        # Get filter values from the request
        status_filter = request.args.get('statusFilter', '')
        last_name_filter = request.args.get('lastNameFilter', '')
        first_name_filter = request.args.get('firstNameFilter', '')
        city_filter = request.args.get('cityFilter', '')

        # Construct base query
        query = """
            SELECT c.customer_id, c.last_name, c.first_name, c.contact_number, c.status,
            a.address_details, a.barangay, a.city, a.postal_code
            FROM customers c
            JOIN addresses a ON c.permanent_address = a.address_id
            WHERE 1=1
        """

        # Add filters to the query
        if status_filter:
            query += " AND c.status = %s"
        if last_name_filter:
            query += " AND c.last_name LIKE %s"
        if first_name_filter:
            query += " AND c.first_name LIKE %s"
        if city_filter:
            query += " AND a.city LIKE %s"

        # Prepare the parameters for the query
        params = []
        if status_filter:
            params.append(status_filter)
        if last_name_filter:
            params.append(f"%{last_name_filter}%")  # For partial search
        if first_name_filter:
            params.append(f"%{first_name_filter}%")  # For partial search
        if city_filter:
            params.append(f"%{city_filter}%")  # For partial search

        # Connect to the database
        connection = connect_to_db()
        cursor = connection.cursor(dictionary=True)

        # Execute the query with filters
        cursor.execute(query, params)
        customers = cursor.fetchall()

        if not customers:
            print("No customers found.")

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        customers = []

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    # Render the template with the filtered customers list
    return render_template('CustomersPage.html', customers=customers)

# managing customers (input)
@app.route('/customers/<customer_id>', methods=['GET', 'POST'])
@app.route('/customers/new', methods=['GET', 'POST'])
def manage_customer(customer_id=None):
    connection = connect_to_db()
    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        last_name = request.form['lastName']
        first_name = request.form['firstName']
        contact_number = request.form['contactNumber']
        address_details = request.form['addressDetails']
        barangay = request.form['barangay']
        city = request.form['city']
        postal_code = request.form['postalCode']

        if customer_id:
            cursor.execute("""
                UPDATE addresses
                SET address_details = %s, barangay = %s, city = %s, postal_code = %s
                WHERE address_id = (
                    SELECT permanent_address FROM customers WHERE customer_id = %s
                )
            """, (address_details, barangay, city, postal_code, customer_id))

            cursor.execute("""
                UPDATE customers
                SET last_name = %s, first_name = %s, contact_number = %s
                WHERE customer_id = %s
            """, (last_name, first_name, contact_number, customer_id))
        else:
            last_address_id = helper.generateID(cursor, "addresses", "address_id")
            last_customer_id = helper.generateID(cursor,  "customers", "customer_id")
            last_reg_id = helper.generateID(cursor, "customer_registration", "registration_id", "REG")
            current_date = date.today()

            cursor.execute("""
                INSERT INTO addresses (address_id, address_details, barangay, city, postal_code)
                VALUES (%s, %s, %s, %s, %s)
            """, (last_address_id, address_details, barangay, city, postal_code))

            cursor.execute("""
                INSERT INTO customers (customer_id, last_name, first_name, contact_number, permanent_address)
                VALUES (%s, %s, %s, %s, %s)
            """, (last_customer_id, last_name, first_name, contact_number, last_address_id))

            cursor.execute("""
                INSERT INTO customer_registration (registration_id, customer_id, date)
                VALUES (%s, %s, %s)
            """, (last_reg_id, last_customer_id, current_date))

        connection.commit()
        connection.close()
        return redirect('/customers')

    if customer_id:
        cursor.execute("""
            SELECT c.customer_id, c.last_name, c.first_name, c.contact_number,
                   a.address_details, a.barangay, a.city, a.postal_code
            FROM customers c
            JOIN addresses a ON c.permanent_address = a.address_id
            WHERE c.customer_id = %s
        """, (customer_id,))
        customer = cursor.fetchone()
    else:
        customer = None

    connection.close()
    return render_template('InputCustomer.html', customer=customer)

# managing contractors
@app.route('/contractors/<contractor_id>', methods=['GET', 'POST'])
@app.route('/contractors/new', methods=['GET', 'POST'])
def manage_contractor(contractor_id=None):
    connection = connect_to_db()
    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        last_name = request.form['lastName']
        first_name = request.form['firstName']
        contact_number = request.form['contactNumber']
        job_title = request.form['jobTitle']
        service_id = request.form['serviceId']
        status = request.form['status']

        if contractor_id:
            # Update existing contractor
            cursor.execute("""
                UPDATE contractors
                SET last_name = %s, first_name = %s, contact_number = %s,
                    job_title = %s, service_id = %s, status = %s
                WHERE contractor_id = %s
            """, (last_name, first_name, contact_number, job_title, service_id, status, contractor_id))
        else:
            # Generate new IDs and insert a new contractor
            last_contractor_id = helper.generateID(cursor, "contractors", "contractor_id")
            last_reg_id = helper.generateID(cursor, "contractor_registration", "registration_id", "REG")
            current_date = date.today()

            cursor.execute("""
                INSERT INTO contractors (contractor_id, last_name, first_name, contact_number, job_title, service_id, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (last_contractor_id, last_name, first_name, contact_number, job_title, service_id, status))

            cursor.execute("""
                INSERT INTO contractor_registration (registration_id, contractor_id, date)
                VALUES (%s, %s, %s)
            """, (last_reg_id, last_contractor_id, current_date))

        connection.commit()
        connection.close()
        return redirect('/contractors')

    if contractor_id:
        # Fetch contractor details for editing
        cursor.execute("""
            SELECT c.contractor_id, c.last_name, c.first_name, c.contact_number,
                   c.job_title, c.service_id, c.status, s.service_type
            FROM contractors c
            LEFT JOIN services s ON c.service_id = s.service_id
            WHERE c.contractor_id = %s
        """, (contractor_id,))
        contractor = cursor.fetchone()
    else:
        contractor = None

    # Fetch all services for the dropdown
    cursor.execute("SELECT service_id, service_type FROM services")
    services = cursor.fetchall()

    connection.close()
    return render_template('InputContractor.html', contractor=contractor, services=services)

@app.route('/electricmeters', methods=['GET', 'POST'])
def electricMeters():
    try:
        connection = connect_to_db()
        cursor = connection.cursor(dictionary=True)

        # Get the filter values from the form
        year_filter = request.args.get('yearFilter')
        status_filter = request.args.get('statusFilter')
        acc_num_filter = request.args.get('accNumFilter')

        # Get distinct years for the dropdown
        cursor.execute("SELECT DISTINCT YEAR(installation_date) AS year FROM meters ORDER BY year DESC")
        years = cursor.fetchall()

        # Base query
        query = """
            SELECT 
                m.meter_id, m.account_number, m.installation_date, m.status, 
                c.last_name, c.first_name,
                a.address_details, a.barangay, a.city, a.postal_code
            FROM meters m
            JOIN customers c ON m.customer_id = c.customer_id
            JOIN addresses a ON m.install_address = a.address_id
        """

        # Add conditions based on the filters
        conditions = []
        if year_filter and year_filter != "-- Select Year --":
            conditions.append(f"YEAR(m.installation_date) = {year_filter}")
        if status_filter and status_filter != "-- Select Status --":
            conditions.append(f"m.status = '{status_filter}'")
        if acc_num_filter:
            conditions.append(f"m.account_number LIKE '%{acc_num_filter}%'")

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        cursor.execute(query)
        meters = cursor.fetchall()

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        meters = []
        years = []

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

    return render_template('ElectricMetersPage.html', meters=meters, years=years)

@app.route('/registration', methods=['GET'])
def registration():
    connection = connect_to_db()
    selected_tab = request.args.get('tab', 'customer')
    try:
        with connection.cursor(dictionary=True) as cursor:
            if selected_tab == 'customer':
                cursor.execute("SELECT c.registration_id, cu.first_name, cu.last_name, c.date "
                               "FROM customer_registration c "
                               "JOIN customers cu ON c.customer_id = cu.customer_id "
                               "ORDER BY c.date DESC, c.registration_id DESC")
                customer_records = cursor.fetchall()
                contractor_records = []
            else:
                cursor.execute("SELECT cr.registration_id, co.first_name, co.last_name, cr.date "
                               "FROM contractor_registration cr "
                               "JOIN contractors co ON cr.contractor_id = co.contractor_id "
                               "ORDER BY cr.date DESC, cr.registration_id DESC")
                contractor_records = cursor.fetchall()
                customer_records = []

    finally:
        connection.close()

    return render_template(
        'Registration.html',
        selected_tab=selected_tab,
        customer_records=customer_records,
        contractor_records=contractor_records
    )

@app.route('/services-availed', methods=['GET'])
def services_availed():
    selected_year = request.args.get('year')
    selected_service_type = request.args.get('service_type')
    contractor_id = request.args.get('contractor_id')  # Get contractor ID from query params

    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Fetch distinct service types for the filter dropdown
            cursor.execute("SELECT DISTINCT service_type FROM services")
            service_types = [row['service_type'] for row in cursor.fetchall()]

            # Base query for services availed
            query = """
                SELECT 
                    s.service_type AS service_name,
                    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
                    m.account_number AS customer_account,
                    CONCAT(con.first_name, ' ', con.last_name) AS contractor_name,
                    DATE_FORMAT(sa.date, '%Y-%m-%d') AS date
                FROM services_availed sa
                JOIN customers c ON sa.customer_id = c.customer_id
                JOIN meters m ON sa.meter_id = m.meter_id
                JOIN services s ON sa.service_id = s.service_id
                JOIN contractors con ON sa.contractor_id = con.contractor_id
                WHERE 1 = 1
            """
            params = []

            # Filter by year if selected
            if selected_year:
                query += " AND YEAR(sa.date) = %s"
                params.append(selected_year)

            # Filter by service type if selected
            if selected_service_type:
                query += " AND s.service_type = %s"
                params.append(selected_service_type)

            # Filter by contractor ID if provided
            if contractor_id:
                query += " AND sa.contractor_id = %s"
                params.append(contractor_id)

            # Order the results by date
            query += " ORDER BY sa.date DESC"
            cursor.execute(query, params)
            records = cursor.fetchall()

            # Fetch distinct years for the year filter
            cursor.execute("SELECT DISTINCT YEAR(date) as year FROM services_availed ORDER BY year DESC")
            years = [row['year'] for row in cursor.fetchall()]

    finally:
        connection.close()

    return render_template(
        'ServicesAvailed.html',
        records=records,
        years=years,
        service_types=service_types,
        selected_year=selected_year,
        selected_service_type=selected_service_type,
        contractor_id=contractor_id
    )

@app.route('/services-availed-input', methods=['GET', 'POST'])
def services_availed_input():
    if request.method == 'POST':
        # Handle form submission
        customer_id = request.form.get('customer_id')
        meter_id = request.form.get('meter_id')
        service_id = request.form.get('service_id')
        contractor_id = request.form.get('contractor_id')
        date = request.form.get('date')

        connection = connect_to_db()
        try:
            with connection.cursor(dictionary=True) as cursor:
                # Insert into services_availed table
                query = """
                    INSERT INTO services_availed (
                        transaction_id,
                        customer_id,
                        meter_id,
                        service_id,
                        contractor_id,
                        date
                    )
                    VALUES (%s, %s, %s, %s, %s, %s)
                """
                # Generate a unique transaction_id
                cursor.execute("SELECT MAX(transaction_id) AS max_transaction_id FROM services_availed")
                max_transaction_id = cursor.fetchone()
                if max_transaction_id and max_transaction_id['max_transaction_id']:
                    transaction_id = f"SER{int(max_transaction_id['max_transaction_id'][3:]) + 1:05}"
                else:
                    transaction_id = "SER00001"

                cursor.execute(query, (transaction_id, customer_id, meter_id, service_id, contractor_id, date))

                # Fetch the service type
                cursor.execute("SELECT service_type FROM services WHERE service_id = %s", (service_id,))
                service_type = cursor.fetchone()
                if service_type:
                    service_type = service_type['service_type']
                    print(f"Service Type: {service_type}")

                # Update the meter's status
                new_status = None
                if service_type == 'Disconnection':
                    new_status = 'disconnected'
                elif service_type == 'Reconnection':
                    new_status = 'connected'
                elif service_type == 'Removal':
                    new_status = 'removed'

                if new_status:
                    print(f"Updating Meter ID {meter_id} to status: {new_status}")
                    try:
                        # Update the meter's status
                        cursor.execute(
                            "UPDATE meters SET status = %s WHERE meter_id = %s",
                            (new_status, meter_id)
                        )

                        # Check if the update was successful
                        affected_rows = cursor.rowcount
                        print(f"Rows affected by the update: {affected_rows}")

                        # Fetch the updated status for verification
                        cursor.execute("SELECT status FROM meters WHERE meter_id = %s", (meter_id,))
                        updated_status = cursor.fetchone()
                        if updated_status:
                            print(f"Updated Status in DB: {updated_status['status']}")
                        else:
                            print("No rows found for the given Meter ID.")
                    except Exception as e:
                        print(f"Error updating meter status: {e}")
                        raise


            connection.commit()
            print("Meter status update committed.")
            return redirect('/services-availed')
        except Exception as e:
            print(f"Error processing service availed: {e}")
            connection.rollback()
            return f"Failed to process service availed: {e}", 500

    # For GET method, render the form
    else:
        connection = connect_to_db()
        try:
            with connection.cursor(dictionary=True) as cursor:
                # Fetch customers
                cursor.execute("SELECT customer_id, CONCAT(first_name, ' ', last_name) AS customer_name FROM customers")
                customers = cursor.fetchall()

                # Fetch services sorted by service ID
                cursor.execute("SELECT service_id, service_type AS service_name FROM services ORDER BY service_id")
                services = cursor.fetchall()

                # Fetch contractors (initially empty, will be filtered dynamically)
                cursor.execute("""
                    SELECT 
                        contractor_id, 
                        CONCAT(first_name, ' ', last_name) AS contractor_name, 
                        job_title 
                    FROM contractors 
                    WHERE status = 'active' 
                    ORDER BY contractor_id
                """)
                contractors = cursor.fetchall()

                # Fetch all meters (initially empty, will be filtered dynamically)
                cursor.execute("""
                    SELECT meter_id, account_number 
                    FROM meters 
                    WHERE status = 'connected' 
                    ORDER BY meter_id
                """)
                meters = cursor.fetchall()

        finally:
            connection.close()

        return render_template(
            'ServicesAvailedInput.html',
            customers=customers,
            services=services,
            contractors=contractors,
            meters=meters
        )

@app.route('/get-meters', methods=['GET'])
def get_meters():
    customer_id = request.args.get('customer_id')
    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Fetch meters connected to the given customer ID and filter out 'removed'
            query = """
                SELECT m.meter_id, m.account_number
                FROM meters m
                WHERE m.customer_id = %s AND m.status IN ('connected', 'disconnected')
                ORDER BY m.meter_id
            """
            cursor.execute(query, (customer_id,))
            meters = cursor.fetchall()
            return {"meters": meters}
    except Exception as e:
        print(f"Error fetching meters: {e}")
        return {"meters": []}, 500
    finally:
        connection.close()

@app.route('/get-contractors', methods=['GET'])
def get_contractors():
    service_id = request.args.get('service_id')
    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Fetch contractors connected to the given service ID
            query = """
                SELECT 
                    contractor_id, 
                    CONCAT(first_name, ' ', last_name) AS contractor_name,
                    job_title
                FROM contractors
                WHERE service_id = %s AND status = 'active'
                ORDER BY contractor_id
            """
            cursor.execute(query, (service_id,))
            contractors = cursor.fetchall()
            return {"contractors": contractors}
    except Exception as e:
        print(f"Error fetching contractors: {e}")
        return {"contractors": []}, 500
    finally:
        connection.close()

@app.route('/get-services', methods=['GET'])
def get_services():
    meter_id = request.args.get('meter_id')

    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Fetch the meter's status
            cursor.execute("SELECT status FROM meters WHERE meter_id = %s", (meter_id,))
            meter = cursor.fetchone()
            if not meter:
                return {"services": []}, 404  # No meter found

            meter_status = meter['status']

            # Determine valid services based on meter status
            if meter_status == 'connected':
                # Allow everything except 'installation' and 'reconnection'
                cursor.execute("""
                    SELECT service_id, service_type AS service_name 
                    FROM services 
                    WHERE service_type NOT IN ('installation', 'reconnection')
                    ORDER BY service_id
                """)
            elif meter_status == 'disconnected':
                # Allow everything except 'installation' and 'disconnection'
                cursor.execute("""
                    SELECT service_id, service_type AS service_name 
                    FROM services 
                    WHERE service_type NOT IN ('installation', 'disconnection')
                    ORDER BY service_id
                """)
            else:
                # No valid services for other statuses
                cursor.execute("""
                    SELECT service_id, service_type AS service_name 
                    FROM services 
                    WHERE service_type NOT IN ('installation')
                    ORDER BY service_id
                """)

            services = cursor.fetchall()
            return {"services": services}

    except Exception as e:
        print(f"Error fetching services: {e}")
        return {"services": []}, 500
    finally:
        connection.close()

@app.route('/services-availed-install', methods=['GET'])
def services_availed_install():
    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            cursor.execute("SELECT customer_id, CONCAT(first_name, ' ', last_name) AS customer_name FROM customers")
            customers = cursor.fetchall()

            cursor.execute("""
                SELECT contractor_id, last_name, first_name, contact_number
                FROM contractors
                WHERE service_id = '00001'
            """)
            contractors = cursor.fetchall()

    finally:
        connection.close()

    return render_template('ServicesAvailedInstall.html', customers=customers, contractors=contractors)

@app.route('/add-meter', methods=['POST'])
def add_meter():
    customer_id = request.form.get('customer_id')
    address_details = request.form.get('address_details')
    barangay = request.form.get('barangay')
    city = request.form.get('city')
    postal_code = request.form.get('postal_code')
    contractor_id = request.form.get('contractor_id')

    connection = connect_to_db()
    try:
        with connection.cursor() as cursor:
            # Generate a unique account number using the helper function
            account_number = helper.generate_account_number(cursor)

            # Generate a unique address_id
            cursor.execute("SELECT MAX(address_id) FROM addresses")
            max_address_id = cursor.fetchone()[0]
            if max_address_id is None:
                address_id = "00001"
            else:
                address_id = f"{int(max_address_id) + 1:05}"

            # Insert into addresses table
            address_query = """
                INSERT INTO addresses (
                    address_id, address_details, barangay, city, postal_code
                )
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(address_query, (address_id, address_details, barangay, city, postal_code))

            # Generate a unique meter_id
            cursor.execute("SELECT MAX(meter_id) FROM meters")
            max_meter_id = cursor.fetchone()[0]
            if max_meter_id is None:
                meter_id = "00001"
            else:
                meter_id = f"{int(max_meter_id) + 1:05}"

            # Insert into meters table
            meter_query = """
                INSERT INTO meters (
                    meter_id, customer_id, install_address, account_number, installation_date, status
                )
                VALUES (%s, %s, %s, %s, CURDATE(), 'connected')
            """
            cursor.execute(meter_query, (meter_id, customer_id, address_id, account_number))

            # Insert new service_availed row
            new_serv_id = helper.generateID(cursor, "services_availed", "transaction_id", "SER")
            service_query = """
                INSERT INTO services_availed (
                    transaction_id, customer_id, meter_id, service_id, contractor_id, date
                )
                VALUES (%s, %s, %s, %s, %s, CURDATE())
            """
            # Assuming "00001" is the service ID for installation
            cursor.execute(service_query, (new_serv_id, customer_id, meter_id, "00001", contractor_id))

        connection.commit()
        return redirect('/services-availed')
    except Exception as e:
        print(f"Error adding meter: {e}")
        connection.rollback()
        return f"Failed to install meter: {e}", 500
    finally:
        connection.close()

@app.route('/bill-generation', methods=['GET'])
def bill_generation():
    # Get filter parameters from the URL
    due_date = request.args.get('due_date')
    status = request.args.get('status')
    account_number = request.args.get('account_number')
    billing_id = request.args.get('billing_id', None)

    # Connect to the database
    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Base query
            query = """
                SELECT 
                    b.billing_id,
                    m.account_number,
                    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
                    b.consumption_fee,
                    b.service_fee,
                    b.total_amount,
                    b.start_date,
                    b.end_date,
                    b.consumption,
                    DATE_FORMAT(b.due_date, '%Y-%m-%d') AS due_date,
                    b.payment_status
                FROM billings b
                JOIN meters m ON b.meter_id = m.meter_id
                JOIN customers c ON m.customer_id = c.customer_id
                WHERE 1=1
            """

            # If a specific billing_id is provided, filter by that
            if billing_id:
                query += " AND b.billing_id = %s"
                params = [billing_id]
            else:
                # Apply filters based on other query parameters
                params = []

                if due_date:
                    query += " AND DATE_FORMAT(b.due_date, '%Y-%m-%d') = %s"
                    params.append(due_date)
                
                if status:
                    query += " AND b.payment_status = %s"
                    params.append(status)
                
                if account_number:
                    query += " AND m.account_number LIKE %s"
                    params.append(f'%{account_number}%')

            # Execute the query with filters
            cursor.execute(query, tuple(params))
            bills = cursor.fetchall()

    finally:
        connection.close()

    # Get the years for the year filter dropdown
    years = get_available_years()

    return render_template(
        'BillGeneration.html',
        bills=bills,
        years=years,
        selected_due_date=due_date,
        selected_status=status,
        selected_account_number=account_number
    )

# helper function
def get_available_years():
    connection = connect_to_db()
    try:
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT DISTINCT YEAR(b.due_date) AS year
                FROM billings b
                ORDER BY year DESC
            """)
            years = cursor.fetchall()
            return years
    finally:
        connection.close()

# Route: Generate Bill (POST)
@app.route('/generate-bill', methods=['POST'])
def generate_bill():
    bill_start = request.form.get('bill_start')
    bill_end = request.form.get('bill_end')
    due_date = request.form.get('due_date')
    consumptions = request.form.to_dict(flat=False)  # Get all form data

    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            for key, consumption_list in consumptions.items():
                if not key.startswith('consumption['):
                    continue

                # Extract meter_id
                meter_id = key[12:-1]  # Strip 'consumption[' and ']'
                consumption = consumption_list[0]

                # Validate data
                if not meter_id.isnumeric() or not consumption.isnumeric():
                    print(f"Invalid data for Meter ID: {meter_id}. Skipping.")
                    continue

                consumption = float(consumption)
                print(f"Processing Meter ID: {meter_id}, Consumption: {consumption} kWh")

                # Generate a new billing_id
                cursor.execute("SELECT MAX(billing_id) FROM billings")
                max_billing_id = cursor.fetchone()['MAX(billing_id)']
                if max_billing_id is None:
                    billing_id = "BIL001"
                else:
                    billing_id = f"BIL{int(max_billing_id[3:]) + 1:03}"

                print(f"Generated Billing ID: {billing_id}")

                # Calculate consumption fee
                consumption_fee = consumption * 12  # Assuming 12 pesos/kWh

                # Fetch service fees for the given meter_id within the billing period
                cursor.execute("""
                    SELECT SUM(s.service_fee) AS total_service_fee
                    FROM services_availed sa
                    JOIN services s ON sa.service_id = s.service_id
                    WHERE sa.meter_id = %s AND sa.date BETWEEN %s AND %s
                """, (meter_id, bill_start, bill_end))
                total_service_fee_result = cursor.fetchone()
                total_service_fee = float(total_service_fee_result['total_service_fee']) if total_service_fee_result['total_service_fee'] else 0.0


                print(f"Total Service Fee for Meter ID {meter_id}: {total_service_fee}")

                # Calculate total amount
                total_amount = consumption_fee + total_service_fee

                # Insert the bill into the billings table
                query = """
                    INSERT INTO billings (
                        billing_id,
                        meter_id,
                        consumption_fee,
                        service_fee,
                        total_amount,
                        start_date,
                        end_date,
                        due_date,
                        payment_status,
                        consumption
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'Unpaid', %s)
                """
                params = (
                    billing_id,
                    meter_id,
                    consumption_fee,
                    total_service_fee,
                    total_amount,
                    bill_start,
                    bill_end,
                    due_date,
                    consumption,
                )

                print(f"Executing Query: {query}")
                print(f"With Parameters: {params}")

                try:
                    cursor.execute(query, params)
                    print(f"Successfully executed for Meter ID: {meter_id}")
                except Exception as e:
                    print(f"Error executing query for Meter ID: {meter_id}. Error: {e}")

        # Commit the transaction
        connection.commit()
        print("Bills successfully generated and committed to the database.")

    except Exception as e:
        print(f"Error occurred during bill generation: {e}")
        connection.rollback()

    finally:
        connection.close()

    return redirect('/bill-generation')

@app.route('/payment', methods=['GET'])
def payments():
    # Extract all filters and sorting parameters from the request
    page = request.args.get('page', 1, type=int)
    per_page = 12
    year_filter = request.args.get('year', None)
    payment_type_filter = request.args.get('payment_type', 'All')
    sort_amount = request.args.get('sort_amount', 'none')
    sort_date = request.args.get('sort_date', 'none')

    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Base query
            query = """
                SELECT 
                    p.payment_id,
                    p.billing_id,
                    p.payment_amount,
                    p.payment_date,
                    p.payment_type,
                    c.first_name,
                    c.last_name
                FROM payments p
                JOIN billings b ON p.billing_id = b.billing_id
                JOIN meters m ON b.meter_id = m.meter_id
                JOIN customers c ON m.customer_id = c.customer_id
                WHERE 1=1
            """

            # Apply filters
            filters = []
            if year_filter and year_filter != 'All':
                query += " AND YEAR(p.payment_date) = %s"
                filters.append(year_filter)
            if payment_type_filter and payment_type_filter != 'All':
                query += " AND p.payment_type = %s"
                filters.append(payment_type_filter)

            # Apply sorting
            order_by = []
            if sort_amount == 'asc':
                order_by.append("p.payment_amount ASC")
            elif sort_amount == 'desc':
                order_by.append("p.payment_amount DESC")
            if sort_date == 'asc':
                order_by.append("p.payment_date ASC")
            elif sort_date == 'desc':
                order_by.append("p.payment_date DESC")

            if order_by:
                query += " ORDER BY " + ", ".join(order_by)

            # Add pagination
            query += " LIMIT %s OFFSET %s"
            filters.extend([per_page, (page - 1) * per_page])

            cursor.execute(query, filters)
            payments = cursor.fetchall()

            # Get total count for pagination
            count_query = """
                SELECT COUNT(*) AS total 
                FROM payments p
                JOIN billings b ON p.billing_id = b.billing_id
                JOIN meters m ON b.meter_id = m.meter_id
                JOIN customers c ON m.customer_id = c.customer_id
                WHERE 1=1
            """
            count_filters = []
            if year_filter and year_filter != 'All':
                count_query += " AND YEAR(p.payment_date) = %s"
                count_filters.append(year_filter)
            if payment_type_filter and payment_type_filter != 'All':
                count_query += " AND p.payment_type = %s"
                count_filters.append(payment_type_filter)

            cursor.execute(count_query, count_filters)
            total_payments = cursor.fetchone()['total']

    finally:
        connection.close()

    total_pages = (total_payments + per_page - 1) // per_page  # Calculate total pages

    return render_template(
        'Payment.html',
        payments=payments,
        page=page,
        total_pages=total_pages,
        year_filter=year_filter,
        payment_type_filter=payment_type_filter,
        sort_amount=sort_amount,
        sort_date=sort_date
    )

# Route: Payment CAN Input (GET)
@app.route('/payment-input', methods=['GET'])
def payment_input():
    return render_template('PaymentInput.html')

# Route: Add Payment (POST)
@app.route('/add-payment', methods=['POST'])
def add_payment():
    billing_id = request.form.get('billing_id')
    payment_type = request.form.get('payment_type')
    payment_date = request.form.get('payment_date')

    connection = connect_to_db()
    try:
        with connection.cursor() as cursor:
            # Fetch the total amount from the billings table using billing_id
            query = """
                SELECT total_amount 
                FROM billings 
                WHERE billing_id = %s
            """
            cursor.execute(query, (billing_id,))
            result = cursor.fetchone()

            if not result:
                return "Invalid billing ID.", 400

            payment_amount = result[0]  # Fetch the total amount

            # Generate a new payment_id
            cursor.execute("SELECT MAX(payment_id) FROM payments")
            max_payment_id = cursor.fetchone()[0]

            if max_payment_id is None:
                payment_id = "PAY001"
            else:
                payment_id = f"PAY{int(max_payment_id[3:]) + 1:03}"

            # Insert the payment into the payments table
            query = """
                INSERT INTO payments (payment_id, billing_id, payment_amount, payment_type, payment_date)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(query, (payment_id, billing_id, payment_amount, payment_type, payment_date))

            # Update the payment status in the billings table
            query = """
                UPDATE billings
                SET payment_status = 'Paid'
                WHERE billing_id = %s
            """
            cursor.execute(query, (billing_id,))

        connection.commit()
    except Exception as e:
        connection.rollback()
        print(f"Error processing payment: {e}")
        return f"Error processing payment: {e}", 500
    finally:
        connection.close()

    return redirect('/payment')

@app.route('/validate-account-number', methods=['GET'])
def validate_account_number():
    account_number = request.args.get('account_number')

    if not account_number:
        return {"exists": False, "hasUnpaidBills": False, "message": "Account number is missing."}, 400

    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Check if the account number exists
            query_exists = "SELECT COUNT(*) AS count FROM meters WHERE account_number = %s"
            cursor.execute(query_exists, (account_number,))
            exists = cursor.fetchone()['count'] > 0

            if not exists:
                return {"exists": False, "hasUnpaidBills": False, "message": "The account number does not exist."}

            # Check if there are unpaid bills
            query_unpaid = """
                SELECT COUNT(*) AS count
                FROM billings b
                JOIN meters m ON b.meter_id = m.meter_id
                WHERE m.account_number = %s AND b.payment_status = 'Unpaid'
            """
            cursor.execute(query_unpaid, (account_number,))
            has_unpaid_bills = cursor.fetchone()['count'] > 0

            if not has_unpaid_bills:
                return {"exists": True, "hasUnpaidBills": False, "message": "The account number has no unpaid bills."}

            return {"exists": True, "hasUnpaidBills": True}
    except Exception as e:
        error_message = f"Error validating account number: {e}"
        print(error_message)
        return {"exists": False, "hasUnpaidBills": False, "message": error_message}, 500
    finally:
        connection.close()

# Route: Get Unpaid Billings (POST)
@app.route('/get-unpaid-billings', methods=['POST'])
def get_unpaid_billings():
    account_number = request.form.get('account_number')

    connection = connect_to_db()
    try:
        with connection.cursor(dictionary=True) as cursor:
            # Fetch unpaid billings for the given account number
            query = """
                SELECT 
                    b.billing_id, 
                    b.total_amount, 
                    DATE_FORMAT(b.due_date, '%Y-%m-%d') AS due_date 
                FROM billings b
                JOIN meters m ON b.meter_id = m.meter_id
                WHERE m.account_number = %s AND b.payment_status = 'Unpaid'
            """
            cursor.execute(query, (account_number,))
            unpaid_billings = cursor.fetchall()

            if not unpaid_billings:
                return "No unpaid billings found for the given account number.", 400

    finally:
        connection.close()

    # Render payment details page with unpaid billings
    return render_template(
        'PaymentDetails.html',
        account_number=account_number,
        unpaid_billings=unpaid_billings
    )

@app.route('/consumption-trend', methods=['GET', 'POST'])
def consumption_trend():
    if request.method == 'POST':
        account_number = request.form.get('accNumInput')
        year = request.form.get('yearInput')
        
        # Convert year to string for date filtering
        start_date = f"{year}-01-01"
        end_date = f"{year}-12-31"

        # SQL query to get basic customer info (first_name, last_name)
        query_customer_info = """
            SELECT first_name, last_name
            FROM customers c
            JOIN meters m ON c.customer_id = m.customer_id
            WHERE m.account_number = %s
        """
        connection = connect_to_db()
        cursor = connection.cursor(dictionary=True)
        cursor.execute(query_customer_info, (account_number,))
        customer_info = cursor.fetchone()

        result = []

        # Loop through each month (1-12 for January to December)
        for month in range(1, 13):
            query = """
                SELECT 
                    SUM(b.consumption) AS consumption, 
                    SUM(b.consumption_fee) * 1.1 AS bill,  -- assuming a fixed calculation for the bill
                    MAX(b.payment_status) AS payment_status
                FROM billings b
                JOIN meters m ON b.meter_id = m.meter_id
                WHERE m.account_number = %s 
                AND MONTH(b.start_date) = %s  -- Filter by specific month
                AND YEAR(b.start_date) = %s  -- Filter by the selected year
            """
            cursor.execute(query, (account_number, month, year))
            monthly_data = cursor.fetchone()

            # If data exists for the month, append it, otherwise add empty/default values
            if monthly_data:
                result.append({
                    'month': calendar.month_name[month],  # Get the month name
                    'consumption': monthly_data['consumption'],
                    'bill': monthly_data['bill'],
                    'payment_status': monthly_data['payment_status']
                })
            else:
                result.append({
                    'month': calendar.month_name[month],  # Month name if no data exists
                    'consumption': 0,  # Default value if no data for the month
                    'bill': 0,
                    'payment_status': 'Not Paid'
                })

        cursor.close()
        connection.close()

        # Return the results to the template
        return render_template('ConsumptionTrend.html', customer_info=customer_info, result=result)

    return render_template('ConsumptionTrend.html')

from datetime import datetime
@app.route('/billing-report', methods=['GET', 'POST'])
def billing_report():
    # Get the selected month and year from the form
    selected_month_year = request.form.get('monthInput')
    if selected_month_year:
        year, month = selected_month_year.split('-')

        # Connect to MySQL database
        conn = connect_to_db()
        cursor = conn.cursor()

        # SQL query to get the necessary data for the selected month and year
        query = """
            SELECT b.billing_id, b.total_amount, b.start_date, b.end_date, b.due_date, b.payment_status, p.payment_amount, p.payment_date
            FROM billings b
            LEFT JOIN payments p ON b.billing_id = p.billing_id
            WHERE YEAR(b.start_date) = %s AND MONTH(b.end_date) = %s
        """
        cursor.execute(query, (year, month))
        result = cursor.fetchall()

        # Initialize variables to store totals and counts for different categories
        total_billed_amount = 0
        total_payment_received = 0
        bills_paid_on_time = 0
        bills_paid_late = 0
        bills_unpaid = 0

        # Loop through the results to calculate totals
        for row in result:
            print(row[1])
            print("---")
            print(row[6])
            total_billed_amount += row[1]  # Total billed amount (from 'total_amount')
            total_payment_received += row[6] if row[6] is not None else 0  # Total payment received (from 'payment_amount')

            # Check if the bill is unpaid
            if row[5] == 'unpaid':  # Check payment_status directly
                bills_unpaid += 1
            else:
                # If there is a payment, check if it's on time or late
                if row[6] is not None:
                    payment_date = row[7]  # 'payment_date'
                    due_date = row[4]  # 'due_date'

                    if payment_date <= due_date:
                        bills_paid_on_time += 1
                    else:
                        bills_paid_late += 1


        # Close the cursor and connection
        cursor.close()
        conn.close()

        # Render the result to the template
        return render_template('BillingReport.html', month=month, year=year, 
                               total_billed_amount=total_billed_amount, 
                               total_payment_received=total_payment_received,
                               bills_paid_on_time=bills_paid_on_time,
                               bills_paid_late=bills_paid_late, 
                               bills_unpaid=bills_unpaid)
    return render_template('BillingReport.html')

@app.route('/meter-op-report', methods=['GET', 'POST'])
def meter_op_report():
    service_counts = None  # Default value to avoid UndefinedError
    error = None
    month = None
    year = None

    if request.method == 'POST':
        month_input = request.form.get('monthInput')
        if not month_input:
            error = "Please select a valid month."
        else:
            # Extract year and month
            year, month = map(int, month_input.split('-'))

            # SQL Query to fetch relevant data
            query = """
            SELECT s.service_type, COUNT(sa.date) AS service_count
            FROM services s
            JOIN services_availed sa ON s.service_id = sa.service_id
            WHERE YEAR(sa.date) = %s AND MONTH(sa.date) = %s
            GROUP BY s.service_type
            """

            # Fetch data from database
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute(query, (year, month))
            result = cursor.fetchall()
            cursor.close()

            # Initialize counters
            service_counts = {
                'removal': 0,
                'reconnection': 0,
                'installation': 0,
                'repair': 0,
                'disconnection': 0
            }

            # Loop through the result and count each service type
            for row in result:
                service_type = row[0].lower()
                service_count = row[1]
                if service_type in service_counts:
                    service_counts[service_type] += service_count

    return render_template(
        'MeterOperationsReport.html',
        service_counts=service_counts,
        error=error,
        month=month,
        year=year
    )

@app.route('/geo-analysis', methods=['GET', 'POST'])
def geo_analysis():
    city_name = None
    average_consumption = None
    average_fee = None
    active_meters_count = 0
    
    if request.method == 'POST':
        city_name = request.form.get('cityNameInput', '').strip()
        
        if city_name:
            # Updated SQL queries to include addresses table
            query_avg_consumption = """
                SELECT AVG(b.consumption) AS avg_consumption, AVG(b.total_amount) AS avg_fee
                FROM billings AS b
                JOIN meters AS m ON b.meter_id = m.meter_id
                JOIN addresses AS a ON m.install_address = a.address_id
                WHERE a.city = %s
            """
            query_active_meters = """
                SELECT COUNT(*) AS active_meters
                FROM meters AS m
                JOIN addresses AS a ON m.install_address = a.address_id
                WHERE m.status = 'connected' AND a.city = %s
            """
            
            # Execute queries
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute(query_avg_consumption, (city_name,))
            result_avg = cursor.fetchone()
            
            cursor.execute(query_active_meters, (city_name,))
            result_active = cursor.fetchone()

            if result_avg:
                average_consumption = round(result_avg[0], 2) if result_avg[0] is not None else None
                average_fee = round(result_avg[1], 2) if result_avg[1] is not None else None 
            if result_active:
                active_meters_count = result_active[0] 
    
    return render_template(
        'GeoAnalysis.html',
        city_name=city_name,
        average_consumption=average_consumption,
        average_fee=average_fee,
        active_meters_count=active_meters_count
    )



if __name__ == '__main__':
    app.run(debug=True)