# ===== VALIDATORS ===== #
def checkNCR(city):
    NCRList = [
        "Caloocan City",
        "Las Piñas City",
        "Makati City",
        "Malabon City",
        "Mandaluyong City",
        "Manila City",
        "Marikina City",
        "Muntinlupa City",
        "Navotas City",
        "Parañaque City",
        "Pasay City",
        "Pasig City",
        "Quezon City",
        "San Juan City",
        "Taguig City",
        "Valenzuela City",
        "Pateros"
    ]
    return city in NCRList

def fixNumber(number):
    # Remove spaces from the number (to handle formatted numbers)
    number = number.replace(" ", "")
    
    # Check if the number is valid (11 digits)
    if len(number) == 11 and number.isdigit():
        # Format the number to XXXX XXX XXXX
        return f"{number[:4]} {number[4:7]} {number[7:]}"
    else:
        return False
    
# ===== GENARATORS ===== #
def generateID(cursor, table, idField, prefix=""):
    cursor.execute(f"SELECT MAX({idField}) AS max_id FROM {table}")
    result = cursor.fetchone()

    if result:
        try:
            last_id = result[0]
        except Exception as e:
            last_id = result['max_id']
        
        number = last_id
        if len(last_id) > 3 and last_id[:3].isalpha():
            number = last_id[3:]
        elif len(last_id) > 3 and last_id[:3].isdigit():
            number = last_id

        new_number = str(int(number) + 1).zfill(5)
    else:
        new_number = '00001'

    if prefix != "":
        new_id = prefix + new_number
    else:
        new_id = new_number

    return new_id

import random
def generate_account_number(cursor):
    while True:
        # Generate a random account number in the format XXXX XXXX XXXX XXXX
        new_can = " ".join(["".join([str(random.randint(0, 9)) for _ in range(4)]) for _ in range(4)])
        
        # Check if this CAN already exists in the meters table
        cursor.execute("SELECT COUNT(*) FROM meters WHERE account_number = %s", (new_can,))
        result = cursor.fetchone()

        # If result is a dictionary, access using the correct key
        if result and result.get('COUNT(*)', 0) == 0:
            return new_can

